chrome.runtime.onInstalled.addListener(()=>{console.log("LinkHub extension installed")});
